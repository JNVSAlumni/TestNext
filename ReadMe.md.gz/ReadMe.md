Some third party software has been used. Their respective license are summarised below:

|Library|Author|Licence|
|---|---|---|
|.Net Core|.NET Foundation and Contributors|[MIT License](https://github.com/dotnet/core/blob/main/LICENSE.TXT)|
|React|Facebook, Inc. and its affiliates|[MIT License](https://github.com/facebook/react/blob/master/LICENSE)|
|Material-UI|Call-Em-All|[MIT License](https://github.com/mui-org/material-ui/blob/next/LICENSE)|
